import{S as _,i as r,s as e}from"./index.5b37bd6f.js";function a(s){return __DATE__,__RELOAD_SW__,[]}class o extends _{constructor(t){super(),r(this,t,a,null,e,{})}}export{o as default};
