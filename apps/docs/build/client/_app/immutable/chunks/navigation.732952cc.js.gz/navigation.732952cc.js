import{j as o}from"./singletons.c185ea9d.js";const t=o("goto");export{t as g};
