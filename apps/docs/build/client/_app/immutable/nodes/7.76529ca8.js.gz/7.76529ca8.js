import{S as W,i as Y,s as k,k as r,q as w,a as y,l,m as B,r as b,h as i,c as H,n as R,b as t,G as A,H as x}from"../chunks/index.5b37bd6f.js";function q(E){let o,p,s,h,g,c,d,m,u,a,f;return{c(){o=r("h1"),p=w("You're being signed in!"),s=y(),h=r("br"),g=w(`

We're logging you in right now! Hold on for a second while we do some magic...

`),c=r("br"),d=y(),m=r("br"),u=y(),a=r("div"),f=w("Hey there! Authflow isn't implemented, so this page is lying to you. :("),this.h()},l(e){o=l(e,"H1",{class:!0});var n=B(o);p=b(n,"You're being signed in!"),n.forEach(i),s=H(e),h=l(e,"BR",{}),g=b(e,`

We're logging you in right now! Hold on for a second while we do some magic...

`),c=l(e,"BR",{}),d=H(e),m=l(e,"BR",{}),u=H(e),a=l(e,"DIV",{class:!0});var v=B(a);f=b(v,"Hey there! Authflow isn't implemented, so this page is lying to you. :("),v.forEach(i),this.h()},h(){R(o,"class","text-5xl"),R(a,"class","text-red-900")},m(e,n){t(e,o,n),A(o,p),t(e,s,n),t(e,h,n),t(e,g,n),t(e,c,n),t(e,d,n),t(e,m,n),t(e,u,n),t(e,a,n),A(a,f)},p:x,i:x,o:x,d(e){e&&i(o),e&&i(s),e&&i(h),e&&i(g),e&&i(c),e&&i(d),e&&i(m),e&&i(u),e&&i(a)}}}class G extends W{constructor(o){super(),Y(this,o,null,q,k,{})}}export{G as component};
