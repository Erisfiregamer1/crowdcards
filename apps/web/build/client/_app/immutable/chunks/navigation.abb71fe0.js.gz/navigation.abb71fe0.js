import{j as o}from"./singletons.eb597214.js";const t=o("goto");export{t as g};
