import{S as b,i as w,s as h,k as i,q as c,l as f,m as k,r as d,h as u,b as p,G as l,H as t}from"../chunks/index.5b37bd6f.js";function g(y){let o,r,s,n;return{c(){o=i("div"),r=c(`If you're here, you are probably offline.
  `),s=i("br"),n=c(`
  Crowdcards works fine offline thanks to PWA technology, but you won't be able to upload cards or log in. Viewing cards will work if you've already checked at least once.`)},l(a){o=f(a,"DIV",{});var e=k(o);r=d(e,`If you're here, you are probably offline.
  `),s=f(e,"BR",{}),n=d(e,`
  Crowdcards works fine offline thanks to PWA technology, but you won't be able to upload cards or log in. Viewing cards will work if you've already checked at least once.`),e.forEach(u)},m(a,e){p(a,o,e),l(o,r),l(o,s),l(o,n)},p:t,i:t,o:t,d(a){a&&u(o)}}}class v extends b{constructor(o){super(),w(this,o,null,g,h,{})}}export{v as component};
