import{S as o,i as t,s as n}from"../chunks/index.5b37bd6f.js";class e extends o{constructor(s){super(),t(this,s,null,null,n,{})}}export{e as component};
